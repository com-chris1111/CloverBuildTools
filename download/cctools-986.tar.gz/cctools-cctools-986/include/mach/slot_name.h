#include <mach/machine.h>
extern void			slot_name(cpu_type_t,
					  cpu_subtype_t,
					  char **,
					  char **);

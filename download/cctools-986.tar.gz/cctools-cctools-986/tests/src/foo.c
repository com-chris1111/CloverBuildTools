#if !defined(FOO)
#define FOO foo
#endif

int FOO(void)
{
  return 0;
}

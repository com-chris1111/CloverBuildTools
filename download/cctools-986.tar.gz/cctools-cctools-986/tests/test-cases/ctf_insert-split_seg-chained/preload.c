int x = 0;
int* g = &x;

int start(void)
{
  return *g;
}

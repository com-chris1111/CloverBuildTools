#import <Foundation/Foundation.h>
#import "hi.h"

@implementation Hi
- (void)greetings
{
  printf("hello, Objective-C!\n");
}
- (void)unused
{
}
@end

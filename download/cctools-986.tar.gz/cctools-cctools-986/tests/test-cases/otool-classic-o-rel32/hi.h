#import <Foundation/Foundation.h>
@interface Hi : NSObject
{
  int payload;
}
- (void)greetings;
- (void)unused;
@end

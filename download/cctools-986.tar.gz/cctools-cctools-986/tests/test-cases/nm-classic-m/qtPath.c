void qtPath(void) {}

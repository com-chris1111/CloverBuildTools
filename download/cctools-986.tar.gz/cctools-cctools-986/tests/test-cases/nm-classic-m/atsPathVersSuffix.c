void atsPathVersSuffix(void) {}

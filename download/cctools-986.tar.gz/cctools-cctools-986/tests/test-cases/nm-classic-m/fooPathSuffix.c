void fooPathSuffix(void){}

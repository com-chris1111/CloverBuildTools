void fooVers(void){}

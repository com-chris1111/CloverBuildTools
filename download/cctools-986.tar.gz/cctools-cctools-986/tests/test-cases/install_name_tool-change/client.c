extern int one(void);

int main(void)
{
  (void)one();
  return 0;
}
